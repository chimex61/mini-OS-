<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Calculator
    Inherits DevComponents.DotNetBar.Metro.MetroForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnDiv = New System.Windows.Forms.Button()
        Me.btnMult = New System.Windows.Forms.Button()
        Me.btnSub = New System.Windows.Forms.Button()
        Me.txtDisp = New System.Windows.Forms.TextBox()
        Me.btnAns = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnNine = New System.Windows.Forms.Button()
        Me.btnEigth = New System.Windows.Forms.Button()
        Me.btnSix = New System.Windows.Forms.Button()
        Me.btnFive = New System.Windows.Forms.Button()
        Me.btnThree = New System.Windows.Forms.Button()
        Me.btnTwo = New System.Windows.Forms.Button()
        Me.btnZero = New System.Windows.Forms.Button()
        Me.btnFour = New System.Windows.Forms.Button()
        Me.btnSeven = New System.Windows.Forms.Button()
        Me.btnOne = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnClear.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.Black
        Me.btnClear.Location = New System.Drawing.Point(247, 381)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(111, 92)
        Me.btnClear.TabIndex = 33
        Me.btnClear.Text = "&C"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnDiv
        '
        Me.btnDiv.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnDiv.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDiv.ForeColor = System.Drawing.Color.Black
        Me.btnDiv.Location = New System.Drawing.Point(364, 381)
        Me.btnDiv.Name = "btnDiv"
        Me.btnDiv.Size = New System.Drawing.Size(111, 92)
        Me.btnDiv.TabIndex = 32
        Me.btnDiv.Text = "&/"
        Me.btnDiv.UseVisualStyleBackColor = False
        '
        'btnMult
        '
        Me.btnMult.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnMult.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMult.ForeColor = System.Drawing.Color.Black
        Me.btnMult.Location = New System.Drawing.Point(364, 283)
        Me.btnMult.Name = "btnMult"
        Me.btnMult.Size = New System.Drawing.Size(111, 92)
        Me.btnMult.TabIndex = 31
        Me.btnMult.Text = "&*"
        Me.btnMult.UseVisualStyleBackColor = False
        '
        'btnSub
        '
        Me.btnSub.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnSub.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSub.ForeColor = System.Drawing.Color.Black
        Me.btnSub.Location = New System.Drawing.Point(364, 185)
        Me.btnSub.Name = "btnSub"
        Me.btnSub.Size = New System.Drawing.Size(111, 92)
        Me.btnSub.TabIndex = 30
        Me.btnSub.Text = "&-"
        Me.btnSub.UseVisualStyleBackColor = False
        '
        'txtDisp
        '
        Me.txtDisp.BackColor = System.Drawing.Color.DarkGray
        Me.txtDisp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDisp.Font = New System.Drawing.Font("Arial Rounded MT Bold", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDisp.ForeColor = System.Drawing.Color.Black
        Me.txtDisp.Location = New System.Drawing.Point(12, 12)
        Me.txtDisp.Name = "txtDisp"
        Me.txtDisp.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.txtDisp.Size = New System.Drawing.Size(463, 50)
        Me.txtDisp.TabIndex = 29
        '
        'btnAns
        '
        Me.btnAns.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAns.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAns.ForeColor = System.Drawing.Color.Black
        Me.btnAns.Location = New System.Drawing.Point(129, 381)
        Me.btnAns.Name = "btnAns"
        Me.btnAns.Size = New System.Drawing.Size(111, 92)
        Me.btnAns.TabIndex = 28
        Me.btnAns.Text = "&="
        Me.btnAns.UseVisualStyleBackColor = False
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAdd.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAdd.ForeColor = System.Drawing.Color.Black
        Me.btnAdd.Location = New System.Drawing.Point(364, 87)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(111, 92)
        Me.btnAdd.TabIndex = 27
        Me.btnAdd.Text = "&+"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'btnNine
        '
        Me.btnNine.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnNine.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNine.ForeColor = System.Drawing.Color.Black
        Me.btnNine.Location = New System.Drawing.Point(247, 87)
        Me.btnNine.Name = "btnNine"
        Me.btnNine.Size = New System.Drawing.Size(111, 92)
        Me.btnNine.TabIndex = 26
        Me.btnNine.Text = "&9"
        Me.btnNine.UseVisualStyleBackColor = False
        '
        'btnEigth
        '
        Me.btnEigth.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnEigth.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEigth.ForeColor = System.Drawing.Color.Black
        Me.btnEigth.Location = New System.Drawing.Point(129, 87)
        Me.btnEigth.Name = "btnEigth"
        Me.btnEigth.Size = New System.Drawing.Size(111, 92)
        Me.btnEigth.TabIndex = 25
        Me.btnEigth.Text = "&8"
        Me.btnEigth.UseVisualStyleBackColor = False
        '
        'btnSix
        '
        Me.btnSix.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnSix.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSix.ForeColor = System.Drawing.Color.Black
        Me.btnSix.Location = New System.Drawing.Point(247, 185)
        Me.btnSix.Name = "btnSix"
        Me.btnSix.Size = New System.Drawing.Size(111, 92)
        Me.btnSix.TabIndex = 24
        Me.btnSix.Text = "&6"
        Me.btnSix.UseVisualStyleBackColor = False
        '
        'btnFive
        '
        Me.btnFive.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnFive.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFive.ForeColor = System.Drawing.Color.Black
        Me.btnFive.Location = New System.Drawing.Point(129, 185)
        Me.btnFive.Name = "btnFive"
        Me.btnFive.Size = New System.Drawing.Size(111, 92)
        Me.btnFive.TabIndex = 23
        Me.btnFive.Text = "&5"
        Me.btnFive.UseVisualStyleBackColor = False
        '
        'btnThree
        '
        Me.btnThree.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnThree.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnThree.ForeColor = System.Drawing.Color.Black
        Me.btnThree.Location = New System.Drawing.Point(247, 283)
        Me.btnThree.Name = "btnThree"
        Me.btnThree.Size = New System.Drawing.Size(111, 92)
        Me.btnThree.TabIndex = 22
        Me.btnThree.Text = "&3"
        Me.btnThree.UseVisualStyleBackColor = False
        '
        'btnTwo
        '
        Me.btnTwo.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnTwo.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTwo.ForeColor = System.Drawing.Color.Black
        Me.btnTwo.Location = New System.Drawing.Point(129, 283)
        Me.btnTwo.Name = "btnTwo"
        Me.btnTwo.Size = New System.Drawing.Size(111, 92)
        Me.btnTwo.TabIndex = 18
        Me.btnTwo.Text = "&2"
        Me.btnTwo.UseVisualStyleBackColor = False
        '
        'btnZero
        '
        Me.btnZero.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnZero.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnZero.ForeColor = System.Drawing.Color.Black
        Me.btnZero.Location = New System.Drawing.Point(12, 381)
        Me.btnZero.Name = "btnZero"
        Me.btnZero.Size = New System.Drawing.Size(111, 92)
        Me.btnZero.TabIndex = 21
        Me.btnZero.Text = "&0"
        Me.btnZero.UseVisualStyleBackColor = False
        '
        'btnFour
        '
        Me.btnFour.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnFour.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFour.ForeColor = System.Drawing.Color.Black
        Me.btnFour.Location = New System.Drawing.Point(12, 185)
        Me.btnFour.Name = "btnFour"
        Me.btnFour.Size = New System.Drawing.Size(111, 92)
        Me.btnFour.TabIndex = 20
        Me.btnFour.Text = "&4"
        Me.btnFour.UseVisualStyleBackColor = False
        '
        'btnSeven
        '
        Me.btnSeven.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnSeven.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSeven.ForeColor = System.Drawing.Color.Black
        Me.btnSeven.Location = New System.Drawing.Point(12, 87)
        Me.btnSeven.Name = "btnSeven"
        Me.btnSeven.Size = New System.Drawing.Size(111, 92)
        Me.btnSeven.TabIndex = 19
        Me.btnSeven.Text = "&7"
        Me.btnSeven.UseVisualStyleBackColor = False
        '
        'btnOne
        '
        Me.btnOne.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnOne.Font = New System.Drawing.Font("Arial Rounded MT Bold", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOne.ForeColor = System.Drawing.Color.Black
        Me.btnOne.Location = New System.Drawing.Point(12, 283)
        Me.btnOne.Name = "btnOne"
        Me.btnOne.Size = New System.Drawing.Size(111, 92)
        Me.btnOne.TabIndex = 17
        Me.btnOne.Text = "&1"
        Me.btnOne.UseVisualStyleBackColor = False
        '
        'Calculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 501)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnDiv)
        Me.Controls.Add(Me.btnMult)
        Me.Controls.Add(Me.btnSub)
        Me.Controls.Add(Me.txtDisp)
        Me.Controls.Add(Me.btnAns)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.btnNine)
        Me.Controls.Add(Me.btnEigth)
        Me.Controls.Add(Me.btnSix)
        Me.Controls.Add(Me.btnFive)
        Me.Controls.Add(Me.btnThree)
        Me.Controls.Add(Me.btnTwo)
        Me.Controls.Add(Me.btnZero)
        Me.Controls.Add(Me.btnFour)
        Me.Controls.Add(Me.btnSeven)
        Me.Controls.Add(Me.btnOne)
        Me.DoubleBuffered = True
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Calculator"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnDiv As System.Windows.Forms.Button
    Friend WithEvents btnMult As System.Windows.Forms.Button
    Friend WithEvents btnSub As System.Windows.Forms.Button
    Friend WithEvents txtDisp As System.Windows.Forms.TextBox
    Friend WithEvents btnAns As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnNine As System.Windows.Forms.Button
    Friend WithEvents btnEigth As System.Windows.Forms.Button
    Friend WithEvents btnSix As System.Windows.Forms.Button
    Friend WithEvents btnFive As System.Windows.Forms.Button
    Friend WithEvents btnThree As System.Windows.Forms.Button
    Friend WithEvents btnTwo As System.Windows.Forms.Button
    Friend WithEvents btnZero As System.Windows.Forms.Button
    Friend WithEvents btnFour As System.Windows.Forms.Button
    Friend WithEvents btnSeven As System.Windows.Forms.Button
    Friend WithEvents btnOne As System.Windows.Forms.Button
End Class
